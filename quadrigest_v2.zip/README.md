# QuadriGest

Sistema de gestão de aluguel de quadriciclos.

## Deploy no Vercel (3 formas)

### 1. Drag & Drop (mais fácil, sem Git)
1. Vá em https://vercel.com → New Project
2. Role até "Or deploy from your local folder"
3. Arraste esta pasta inteira
4. Clique Deploy

### 2. Vercel CLI
```bash
npm i -g vercel
cd quadrigest_v2
vercel --prod
```

### 3. GitHub
1. Crie repo no GitHub com estes arquivos
2. Importe no vercel.com → New Project → Import Git Repository

## Dados
Salvos no localStorage do navegador.  
Use Exportar/Importar para backup em JSON.
